﻿#pragma once


class s_command
{
public:
	virtual void execute() = 0;
};
