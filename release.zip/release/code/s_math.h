﻿#pragma once

double distance_cal(double p1[3], double p2[3]);

void direction_cal(double p1[3], double p2[3], double& out_x, double& out_y, double& out_z);
